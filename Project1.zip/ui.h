#ifndef UI_H
#define UI_H

void userInput(int show);
void flushBuffer();
void exitGame();
int checkEOF(int test);
#endif
